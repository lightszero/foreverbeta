﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace tr_map
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Bitmap bmp = new Bitmap(512, 64);
            DrawAction = (x, y, color) =>
            {
                bmp.SetPixel(x, y, color);
            };
            GenWorld(bmp.Width, bmp.Height, DrawAction);
            pictureBox1.Image = bmp;

        }

        Action<int, int, Color> DrawAction;


        static Random ran = null;
        static double ranNumber(double min, double max)
        {
            if (ran == null)
            {
                ran = new Random();
            }
            return min + (max - min) * ran.NextDouble();
        }
        static int ranNumberInt(double min, double max)
        {
            if (ran == null)
            {
                ran = new Random();
            }
            return (int)(min + (max - min) * ran.NextDouble());
        }
        void GenWorld(int width, int height, Action<int, int, Color> _drawfunc)
        {
            float sPower = (float)height / 1024.0f;
            Random ran = new Random();
            //决定两根世界线
            double worldLine1 = (double)height * 0.25f * ranNumber(0.9, 1.1);
            double worldLine2 = (double)height * 0.5 * ranNumber(0.9, 1.1);

            //查找线路
            double line1Min = worldLine1;
            double line1Max = worldLine1;
            double line2Min = worldLine2;
            double line2Max = worldLine2;
            //保存每一列的line1,line2
            double[] wl1 = new double[width];
            double[] wl2 = new double[width];
            int seed = 0;//随机种子
            int seedlen = 0;//随机种子使用步长
            for (int x = 0; x < width; x++)
            {


                float floatx = (float)x / (float)width;
                if (seedlen <= 0)
                {
                    seed = ranNumberInt(0, 5);//随机出五种情况
                    seedlen = (int)(ranNumber(5, 40) * sPower);//这种情况的处理步长
                    if (seed == 0)
                    {
                        seedlen = (int)(seedlen * ranNumber(1, 6) * sPower);
                    }
                }
                seedlen--;
                if (seed == 0)//上上下下摆动，下挖的几率比较高
                {
                    while (ranNumber(0, 7) == 0)
                    {
                        worldLine1 += (double)ranNumber(-1, 2) * sPower;
                    }
                }
                else if (seed == 1)//先高再低，高的几率比较高
                {
                    while (ranNumberInt(0, 4) == 0)//高出
                    {
                        worldLine1 -= 1.0 * sPower;
                    }
                    while (ranNumberInt(0, 10) == 0)//挖下
                    {
                        worldLine1 += 1.0 * sPower;
                    }
                }
                else if (seed == 2)//先低再高，低得的几率比较高
                {
                    while (ranNumberInt(0, 4) == 0)
                    {
                        worldLine1 += 1.0 * sPower;
                    }
                    while (ranNumberInt(0, 10) == 0)
                    {
                        worldLine1 -= 1.0 * sPower;
                    }
                }
                else if (seed == 3)//先高再低，大角度版
                {
                    while (ranNumberInt(0, 2) == 0)
                    {
                        worldLine1 -= 1.0 * sPower;
                    }
                    while (ranNumberInt(0, 6) == 0)
                    {
                        worldLine1 += 1.0 * sPower;
                    }
                }
                else if (seed == 4)//先低再高，大角度版
                {
                    while (ranNumberInt(0, 2) == 0)
                    {
                        worldLine1 += 1.0 * sPower;
                    }
                    while (ranNumberInt(0, 5) == 0)
                    {
                        worldLine1 -= 1.0 * sPower;
                    }
                }


                //限制范围

                if (worldLine1 < (double)height * 0.17)
                {
                    worldLine1 = (double)height * 0.17;
                    seedlen = 0;
                }
                else
                {
                    if (worldLine1 > (double)height * 0.30)
                    {
                        worldLine1 = (double)height * 0.30;
                        seedlen = 0;
                    }
                }
                //在两边靠近边界的地方限制深度
                if ((floatx < 0.1 || floatx > 0.9) && worldLine1 > (double)height * 0.25)
                {
                    worldLine1 = (double)height * 0.25;
                    seedlen = 1;
                }



                //插值为自循环的
                if (floatx >= 0.75f)
                {
                    float needx = 1.0f - floatx;
                    float v = (floatx - 0.75f) / 0.25f;

                    double n1 = wl1[(int)(needx * (float)width)] - wl1[0];
                    worldLine1 = worldLine1 * (1 - v) + (wl1[0] - n1) * v;
                    //double n2 = wl2[(int)(needx * (float)width)] - wl2[0];
                    //worldLine2 = worldLine2 * (1 - v) + (wl2[0] - n2) * v;
                }

                //深层地表根据表层生成
                while (ranNumberInt(0, 3) == 0)//一定几率摆动
                {
                    worldLine2 += (float)ranNumberInt(-2, 3) * sPower;
                }
                //小小的调整
                if (worldLine2 < worldLine1 + (double)height * 0.05 )
                {
                    worldLine2 += 1.0 * sPower;
                }
                if (worldLine2 > worldLine1 + (double)height * 0.35 )
                {
                    worldLine2 -= 1.0 * sPower;
                }

                ////插值为自循环的
                if (floatx >= 0.75f)
                {
                    float needx = 1.0f - floatx;
                    float v = (floatx - 0.75f) / 0.25f;

                    //double n1 = wl1[(int)(needx * (float)width)] - wl1[0];
                    //worldLine1 = worldLine1 * (1 - v) + (wl1[0] - n1) * v;
                    double n2 = wl2[(int)(needx * (float)width)] - wl2[0];
                    worldLine2 = worldLine2 * (1 - v) + (wl2[0] + n2) * v;
                }
                wl1[x] = worldLine1;
                wl2[x] = worldLine2;
                line1Min = line1Min < worldLine1 ? line1Min : worldLine1;
                line1Max = line1Max > worldLine1 ? line1Max : worldLine1;
                line2Min = line2Min < worldLine1 ? line2Min : worldLine1;
                line2Max = line2Max > worldLine1 ? line2Max : worldLine1;
                for (int y = 0; y < height; y++)
                {
                    if (y < (int)worldLine1)
                    {
                        _drawfunc(x, y, Color.Black);
                    }
                    else if (y < (int)worldLine2)
                    {
                        _drawfunc(x, y, Color.SandyBrown);
                    }
                    else
                    {
                        _drawfunc(x, y, Color.RosyBrown);
                    }
                }
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
